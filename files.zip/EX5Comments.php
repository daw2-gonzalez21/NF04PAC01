<html>
 <head>
  <title>Comentarios</title>
 </head>
 <body>
     <h2>Lista de 10 conceptos importantes:</h2>
     <ul>
         <li>$query</li>
         <li>for</li>
         <li>variables</li>
         <li>rows</li>
         <li>tables</li>
         <li>Codenvy</li>
         <li>INSERTS</li>
         <li>PHP</li>
         <li>PUSH TO GITHUB</li>
         <li>MYSQL</li>
     </ul>
     <p>Califica el documento: </p>
     <p>Califica la explicación del profesor: </p>
     <p>Me ha costado mucho porque no encontraba la manera de realizar los ejercicios.
     </p>
 </body>
</html>