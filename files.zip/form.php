<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
</head>
<body>
	<form action="add.php" method="POST">
		<label for="pelicula">Selecciona la pelicula</label>
		<select name="pelicula">
			<option value="">Select movie...</option>
			<option value="1">Valerian and the City of a Thousand Planets</option>
			<option value="2">Blade Runner 2049</option>
			<option value="3">Godzilla: King of Monsters</option>
		</select>
		<br>
		<label for="reviewer">Reviewer:</label>
		<input type="text" name="reviewer">
		<br>
		<label for="comment">Comment:</label>
		<input type="text" name="comment">
		<br>
		<label for="rating">Rating:</label>
		<select name="rating">
			<option value="">Select rating...</option>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
			<option value="5">5</option>
		</select>
		<br>
		<input type="submit" value="Enviar">
	</form>
</body>
</html>