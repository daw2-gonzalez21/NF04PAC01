<html>
 <head>
  <title>Multipurpose Form</title>
  <style type="text/css">
  <!--
td {vertical-align: top;}
  -->
  </style>
 </head>
 <body>
  <form action="suma1.php" method="post">
   <table>
    <tr>
     <td>Introduce el primer numero: </td>
     <td>
      <input type="number" name="numero1">
     </td>
    </tr>
    <tr>
     <td>Introduce el segundo numero:</td>
     <td>
      <input type="number" name="numero2">
     </td>
    </tr>
    <tr>
     <td>Introduce el primer numero: </td>
     <td>
        <input type="number" name="numero3">
     </td>
    </tr>
    <tr>
     <td colspan="1" style="text-align: left;"> 
      <input type="submit" name="submit" value="Continuar" />
     </td>
    </tr>
   </table>
  </form>
 </body>
</html>