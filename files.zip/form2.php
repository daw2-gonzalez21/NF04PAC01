<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title></title>
</head>
<body>
	<form action="asd.php" method="POST">
		<label for="uno">Valor 1:</label>
		<input type="text" name="uno">
		<br>
		<label for="dos">Valor 2:</label>
		<input type="text" name="dos">
		<br>
		<label for="tres">Valor 3:</label>
		<input type="text" name="tres">
		<br>
		<input type="submit" value="Enviar">
	</form>
</body>
</html>