<?php
$db = mysqli_connect('localhost', 'root', 'raulziborc00') or 
    die ('Unable to connect. Check your connection parameters.');
mysqli_select_db($db, 'moviesite') or die(mysqli_error($db));
$fecha = "2020-12-02";
$pelicula = $_POST['pelicula'];
$reviewer = $_POST['reviewer'];
$rating = $_POST['rating'];
$comment = $_POST['comment'];
//insert new data into the reviews table
$query = <<<ENDSQL
INSERT INTO reviews
    (review_movie_id, review_date, reviewer_name, review_comment, review_rating)
VALUES 
    ('$pelicula','$fecha', '$reviewer', '$comment', '$rating')
ENDSQL;
mysqli_query($db, $query) or die(mysqli_error($db));

echo 'Datos insertados';
echo "<a href='N3P308details.php?movie_id=".$pelicula."'>Ver cambios</a>";
?>