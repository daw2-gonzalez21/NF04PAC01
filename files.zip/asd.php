

<select name="opciones">
	<option value="">...</option>
	<option value="1"><?php echo $_POST['uno'];?></option>
	<option value="2"><?php echo $_POST['dos'];?></option>
	<option value="3"><?php echo $_POST['tres'];?></option>
</select>